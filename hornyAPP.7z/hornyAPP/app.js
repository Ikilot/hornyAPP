let btnM = document.getElementById('btnM');
let btnA = document.getElementById('btnA');
let btnC = document.getElementById('btnC');

let screenM = document.getElementById('screenM');
let screenA = document.getElementById('screenA');
let screenC = document.getElementById('screenC');

let btnS = document.getElementById('btnS');
let btnH = document.getElementById('btnH');
let btnI = document.getElementById('btnI');

let caseS = document.getElementById('caseS');
let caseH = document.getElementById('caseH');
let caseI = document.getElementById('caseInv');

let img = document.getElementById('clickImg');
let bar = document.getElementById('bar');
let counter = document.getElementById('counter');
let progresBar = document.getElementById('progres');
let count = 0;
let progres = 0;

counter.innerHTML = 'SCORE: ' + count;

img.onclick = function(){
  progres+=2;
  if(progres < 110){
    progresBar.style.width = progres + '%';
  }
  if(progres == 100){
    progres = 0;
    count++;
    counter.innerHTML = 'SCORE: ' + count;
  }
}
screenM.classList.add('Visible');
caseS.classList.add('Visible');

btnM.onclick = function() {
    screenM.classList.add('Visible');
    screenA.classList.remove('Visible');
    screenC.classList.remove('Visible');
}
btnA.onclick = function() {
    screenA.classList.add('Visible');
    screenM.classList.remove('Visible');
    screenC.classList.remove('Visible');
}
btnC.onclick = function() {
    screenC.classList.add('Visible');
    screenM.classList.remove('Visible');
    screenA.classList.remove('Visible');
}

btnS.onclick = function() {
    caseS.classList.add('Visible');
    caseH.classList.remove('Visible');
    caseI.classList.remove('Visible');
}
btnH.onclick = function() {
    caseH.classList.add('Visible');
    caseI.classList.remove('Visible');
    caseS.classList.remove('Visible');
}
btnI.onclick = function() {
    caseI.classList.add('Visible');
    caseH.classList.remove('Visible');
    caseS.classList.remove('Visible');
}


