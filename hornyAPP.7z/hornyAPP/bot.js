
const TelegramBot = require('node-telegram-bot-api');
const express = require('express');
const token = '';
const app = express();
const bot = new TelegramBot(token, {polling: true});

bot.on('message', msg => {
    userId = msg.from.id;
    userName = msg.from.first_name;
    console.log(userId);
    console.log(userName);
  
    bot.sendMessage(msg.chat.id, 'Привет: ' + userName);
  });