const tg = window.Telegram.WebApp;
const name = tg.initDataUnsafe.user.first_name;
const id = tg.initDataUnsafe.user.id;
const place = document.getElementById('place');
tg.ready();
tg.expand();
place.innerHTML = name;
